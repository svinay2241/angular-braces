import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor() {}
  expr = '';
  output = '';
  areBracketsBalanced(exprr) {
    // Using ArrayDeque is faster
    // than using Stack class
    let stack = [];

    // Traversing the this.expression
    for (let i = 0; i < exprr.length; i++) {
      let x = exprr[i];

      if (x == '(' || x == '[' || x == '{') {
        // Push the element in the stack
        stack.push(x);
        continue;
      }

      // If current character is not opening
      // bracket, then it must be closing.
      // So stack cannot be empty at this point.
      if (stack.length == 0) return false;

      let check;
      switch (x) {
        case ')':
          check = stack.pop();
          if (check == '{' || check == '[') return false;
          break;

        case '}':
          check = stack.pop();
          if (check == '(' || check == '[') return false;
          break;

        case ']':
          check = stack.pop();
          if (check == '(' || check == '{') return false;
          break;
      }
    }

    // Check Empty Stack
    return stack.length == 0;
  }

  balanceBrackets() {
    // Function call
    if (this.areBracketsBalanced(this.expr)) this.output = 'True';
    else this.output = 'False';
  }
}
