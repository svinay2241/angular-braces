import { Component, Input, ElementRef } from '@angular/core';

@Component({
  selector: 'hello',
  template: `
    <input type="file" id="file">
    <button type="button" (click)="update()">Click Me</button>
  `,
  styles: [`h1 { font-family: Lato; }`]
})
export class HelloComponent  {
  @Input() name: string;

  constructor(private elementRef: ElementRef) {}

  update() {
    const file = <HTMLInputElement>this.elementRef.nativeElement.querySelector('#file');

    const formData = new FormData();

    console.log(file.files[0]);

    formData.append('photo', file.files[0]);

    const body = {content: formData};

    formData.append('something', 'value');
    
    console.log(formData.get('photo'));
  }
}
